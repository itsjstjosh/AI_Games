| resource             | author      | licence | notes |
| :------------------- | :---------: | :------ | :---- |
| country.mp3          | [@emegeme](https://github.com/emegeme) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) | Originally created for "DART that TARGET" game |
| target.ogg           | [@emegeme](https://github.com/emegeme) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) | Originally created for "DART that TARGET" game |
| target.flac          | [@emegeme](https://github.com/emegeme) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) | Originally created for "DART that TARGET" game |
| coin.wav             | [@raysan5](https://github.com/raysan5) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) | Created using [rFXGen](https://raylibtech.itch.io/rfxgen) |
| sound.wav            | [@raysan5](https://github.com/raysan5) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) | Created using [rFXGen](https://raylibtech.itch.io/rfxgen) |
| spring.wav           | [@raysan5](https://github.com/raysan5) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) | Created using [rFXGen](https://raylibtech.itch.io/rfxgen) |
| weird.wav            | [@raysan5](https://github.com/raysan5) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) | Created using [rFXGen](https://raylibtech.itch.io/rfxgen) |
| mini1111.xm          | [tPORt](https://modarchive.org/index.php?request=view_by_moduleid&query=51891) | [Mod Archive Distribution license](https://modarchive.org/index.php?terms-upload) | - |
